<?php
$mensagem = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"]) && isset($_POST["senha"])) {
    if ($_POST["login"] == "etec" && $_POST["senha"] == "informática") {
        $mensagem = "<p class='text-success'>Logado com sucesso!</p>";
    } else {
        $mensagem = "<p class='text-danger'>Usuário ou senha incorretos.</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h1>Login</h1>
    <form method="post">
        <div class="mb-3">
            <label class="form-label">Login:</label>
            <input type="text" class="form-control" name="login" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Senha:</label>
            <input type="password" class="form-control" name="senha" required>
        </div>
        <button type="submit" class="btn btn-primary">Entrar</button>
    </form>
    <?= $mensagem; ?>
</body>
</html>
