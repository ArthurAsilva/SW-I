<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"] ?? "";
    $email = $_POST["email"] ?? "";
    $data_nascimento = $_POST["data_nascimento"] ?? "";
    $cartao = $_POST["cartao"] ?? "";
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dados Pessoais</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h1>Preencher Dados</h1>
    <form method="post">
        <div class="mb-3">
            <label class="form-label">Nome:</label>
            <input type="text" class="form-control" name="nome" required>
        </div>
        <div class="mb-3">
            <label class="form-label">E-mail:</label>
            <input type="email" class="form-control" name="email" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Data de Nascimento:</label>
            <input type="date" class="form-control" name="data_nascimento" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Número do Cartão:</label>
            <input type="text" class="form-control" name="cartao" required>
        </div>
        <button type="submit" class="btn btn-primary">Enviar</button>
    </form>
    <?php if ($_SERVER["REQUEST_METHOD"] == "POST") echo "<p class='mt-3'>Dados Recebidos: $nome, $email, $data_nascimento, $cartao</p>"; ?>
</body>
</html>
