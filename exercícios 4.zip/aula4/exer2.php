<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["num1"]) && isset($_GET["num2"]) && isset($_GET["num3"])) {
    $num1 = floatval($_GET["num1"]);
    $num2 = floatval($_GET["num2"]);
    $num3 = floatval($_GET["num3"]);
    $maior = max($num1, $num2, $num3);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maior Número</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h1>Verificar Maior Número</h1>
    <form method="get">
        <div class="mb-3">
            <label class="form-label">Número 1:</label>
            <input type="number" class="form-control" name="num1" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Número 2:</label>
            <input type="number" class="form-control" name="num2" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Número 3:</label>
            <input type="number" class="form-control" name="num3" required>
        </div>
        <button type="submit" class="btn btn-primary">Verificar</button>
    </form>
    <?php if (isset($maior)) echo "<p class='mt-3'>O maior número é: $maior</p>"; ?>
</body>
</html>
