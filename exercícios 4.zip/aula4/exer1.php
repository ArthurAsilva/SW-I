<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["nota1"]) && isset($_GET["nota2"]) && isset($_GET["nota3"])) {
    $nota1 = floatval($_GET["nota1"]);
    $nota2 = floatval($_GET["nota2"]);
    $nota3 = floatval($_GET["nota3"]);
    $media = ($nota1 + $nota2 + $nota3) / 3;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calcular Média</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h1>Calcular Média</h1>
    <form method="get">
        <div class="mb-3">
            <label class="form-label">Nota 1:</label>
            <input type="number" class="form-control" name="nota1" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Nota 2:</label>
            <input type="number" class="form-control" name="nota2" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Nota 3:</label>
            <input type="number" class="form-control" name="nota3" required>
        </div>
        <button type="submit" class="btn btn-primary">Calcular</button>
    </form>
    <?php if (isset($media)) echo "<p class='mt-3'>Média: $media</p>"; ?>
</body>
</html>
