<?php
$corEscolhida = isset($_POST["cor"]) ? $_POST["cor"] : "white";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Escolha de Cor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5" style="background-color: <?= $corEscolhida; ?>;">
    <h1>Escolha a Cor de Fundo</h1>
    <form method="post">
        <select name="cor" class="form-select mb-3">
            <option value="white">Branco</option>
            <option value="yellow">Amarelo</option>
            <option value="blue">Azul</option>
            <option value="red">Vermelho</option>
            <option value="green">Verde</option>
        </select>
        <button type="submit" class="btn btn-primary">Alterar Cor</button>
    </form>
</body>
</html>
